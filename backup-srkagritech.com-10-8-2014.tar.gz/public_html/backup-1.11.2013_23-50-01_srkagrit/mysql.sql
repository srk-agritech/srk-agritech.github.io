-- cPanel mysql backup
GRANT USAGE ON *.* TO 'srkagrit'@'localhost' IDENTIFIED BY PASSWORD '*183837958409CDA10AFF33B0B035FBBFE6320380';
GRANT ALL PRIVILEGES ON `srkagrit\_%`.* TO 'srkagrit'@'localhost';
